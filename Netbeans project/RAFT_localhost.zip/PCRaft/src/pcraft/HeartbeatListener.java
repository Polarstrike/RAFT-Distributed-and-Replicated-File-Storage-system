/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.IOException;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.Set;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Giacomo
 */
public class HeartbeatListener extends Thread{
    private static final int HBport = 9090;    
    private static final int VoteReplyPort = 9092;
    private static final int LeaderSyncPort = 9095;
    private final NodeState state;
    
    public HeartbeatListener(NodeState s){
        this.state = s;
    }
    
    @Override
    public void run(){
        int timeout=0;
        int timeoutCounter = 0;
        boolean firstTimeFollower = true;
        boolean firstTimeLeader = true;
        boolean firstTimeCandidate = true;
        FileListenerNode fileListenerNode = null;
        
        try{
            ServerSocket listener = new ServerSocket(HBport, 50, state.nodeAddress);
            System.out.println("Server #"+state.getNodeId()+" ready... listening for Heartbeat\tSTATE: "+state.getCurrentState());
            while(true){
                int s = state.getCurrentState();
                //state.restoreElection();
                if(s == 0){                         //FOLLOWER
                    //System.out.println("follower");
                    firstTimeLeader = firstTimeCandidate = true;
                    Heartbeat hb = null;
                    if(firstTimeFollower == true){      //spawn fileListener
                        firstTimeFollower = false;                        
                        fileListenerNode = new FileListenerNode(state);
                        fileListenerNode.start();
                    }
                    try{
                        timeout = RandomTime.electionTimeout();
                        listener.setSoTimeout(timeout);
                        Socket socket = listener.accept();
                        Object obj = Receiver.receive(socket);
                        if(obj instanceof Heartbeat){
                            hb = (Heartbeat) obj;
                            if (hb.getTerm() >= state.getCurrentTerm()) {
                                state.setLeaderId(hb.getLeaderId());
                                state.setVotedFor(hb.getLeaderId());
                            }

                            if (hb.getTerm() > state.getCurrentTerm()) {
                                state.setCurrentTerm(hb.getTerm());
                            }

                            timeoutCounter=0;
                            HeartbeatReply reply;
                            
                            //added
                            if(hb.getTerm() < state.getCurrentTerm()){
                                //old leader, time to kill him
                                reply = new HeartbeatReply(state.getCurrentTerm(), false, state.getNodeId());
                                System.out.println("Heartbeat received from OLD leader (" + hb.getLeaderId()+")(Senderterm "+hb.getTerm()+")\tMyTerm: "+state.getCurrentTerm()+"\tFor me leader is: "+state.getLeaderId()+"\tReplied: "+reply.isSuccess()+"\tCONVERTING HIM TO FOLLOWER");                            
                                
                            }
                            else{   //GOOD HEARTBEAT
                                reply = new HeartbeatReply(state.getCurrentTerm(), true, state.getNodeId());
                                System.out.println("Heartbeat received from leader (" + hb.getLeaderId()+")(Senderterm "+hb.getTerm()+")\tMyTerm: "+state.getCurrentTerm()+"\tFor me leader is: "+state.getLeaderId()+"\tReplied: "+reply.isSuccess());                            
                            }
                            //
                            
                            /* ORIGINAL
                            reply = new HeartbeatReply(state.getCurrentTerm(), true, state.getNodeId());
                            System.out.println("Heartbeat received from leader (" + hb.getLeaderId() + ")(Senderterm " + hb.getTerm() + ")\tMyTerm: " + state.getCurrentTerm() + "\tFor me leader is: " + state.getLeaderId() + "\tReplied: " + reply.isSuccess());
                            */
                            Sender.send(state.addresses[hb.getLeaderId()], HBport, reply);
                            socket.close();
                        }
                        
                    } catch (SocketTimeoutException ex){
                        timeoutCounter++;
                        //remain follower if i have voted already
                        //added
                        int votedFor = state.getVotedFor();
                        if(votedFor == -1 || votedFor == state.getLeaderId()){          //not yet voted -> become candidate
                            System.out.println("#"+timeoutCounter+" Timeout (" + timeout + " msec elapsed) -> BECOMING CANDIDATE "+System.currentTimeMillis());
                            state.setCurrentState(1);                            
                        }
                        else{                                   //stay follower
                            System.out.println("#"+timeoutCounter+" Timeout (" + timeout + " msec elapsed) -> remaining follower (already voted for "+votedFor+")");
                        }
                        
                        
                        //
                        /* ORIGINAL
                        System.out.println("#"+timeoutCounter+" Timeout (" + timeout + " msec elapsed) -> BECOMING CANDIDATE "+System.currentTimeMillis());
                        state.setCurrentState(1);
                        */
                    } catch (BindException ex){
                        System.out.println("Bindex "+state.addresses[hb.getLeaderId()]);
                        Logger.getLogger(HeartbeatListener.class.getName()).log(Level.SEVERE, null, ex);
                        
                    } catch (SocketException ex){
                        System.err.println("socket exception");
                    } catch (ClassNotFoundException ex) {
                        Logger.getLogger(HeartbeatListener.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                else if(s == 1){                    //CANDIDATE
                    firstTimeLeader = true;
                    if(firstTimeCandidate){
                        firstTimeCandidate = false;
                        state.becomeCandidate();    //i am now a candidate
                        System.out.println("Now candidate in term: "+state.getCurrentTerm()); 
                        ServerSocket VoteReplyListener = new ServerSocket(VoteReplyPort, 50, state.nodeAddress);
                        //spawn VoteRequesters
                        VoteRequester[] requesters = new VoteRequester[state.N_nodes];
                        for(int i=0; i<state.N_nodes; i++)
                            if(i!=state.getNodeId()){
                                requesters[i] = new VoteRequester(state, i, VoteReplyListener);
                                requesters[i].start();
                            }
                        
                        //Wait for VoteRequester to be done
                        for(int i=0; i<state.N_nodes; i++)
                            if(i!=state.getNodeId())
                                requesters[i].join();
                            
                        //ELECTION AFTERMATH
                        System.out.println("VoteProcedure completed. Obtained " + state.getObtainedVote() + " vote out of " + state.N_nodes + " nodes");
                        if(state.getObtainedVote() > (state.N_nodes/2)){    //MAJORITY REACHED
                            System.out.println("Majority reached, i am the new leader " +System.currentTimeMillis() + firstTimeLeader);
                            state.setCurrentState(2);        //become leader
                        }
                        else{
                            System.out.println("Majority NOT reached, returning follower " +System.currentTimeMillis());                            
                            state.setCurrentState(0);
                            state.restoreElection();
                        }
                        
                        VoteReplyListener.close();
                        
                    }
                }
                else if(s == 2){                    //LEADER
                    firstTimeCandidate = firstTimeFollower = true;
                    LeaderHeartbeat[] l = new LeaderHeartbeat[state.N_nodes];
                    ServerSocket syncListenerSocket = null;
                    Semaphore sem = null;
                    if(firstTimeLeader){                    //spawn Heartbeaters
                        firstTimeLeader = false;
                        if(fileListenerNode != null)
                            fileListenerNode.getListener().close(); //close this socket to force the thread to stop (safely)
                        //LeaderSyncListener start
                        syncListenerSocket = new ServerSocket(LeaderSyncPort, 50, state.nodeAddress);
                        LeaderSyncListener syncListener = new LeaderSyncListener(state, syncListenerSocket);
                        syncListener.start();
                        //
                        
                        state.setLeaderId(state.getNodeId());
                        state.setVotedFor(state.getNodeId());
                        //System.out.println("I AM LEADER votedFor " + state.getVotedFor());
                        listener.setSoTimeout(30);
                        sem = new Semaphore(state.N_nodes-1);
                        for(int i=0; i<state.N_nodes; i++){
                            if(i!=state.getNodeId()){
                                l[i] = new LeaderHeartbeat(state, i, listener, sem);
                                l[i].setName("LeaderHB_"+i);
                                l[i].start();
                                sem.acquire();
                            }
                        }
                    }
                    //System.out.println("all spawned blocking");
                    if(sem!=null)
                        sem.acquire();          //block here until a LeaderHeartbeat dies
                    //System.out.println("unblocked");
                    //System.out.println("Turning off all other LeaderHeartbeat threads");
                    
                    // added
                    //If a leaderHeartbeat thread have finish (newer leader discovered)
                    //shut down all and turn follower
                    
                    for (int i = 0; i < state.N_nodes; i++) {
                        if (i != state.getNodeId()) {
                            //System.out.println("check "+l[i].getName()+"\tState "+l[i].getState());
                            //System.out.println("Interrupting "+l[i].getName());
                            //shutdown all LeaderHeartbeat threads
                            l[i].interrupt();
                            
                        }
                    }
                    syncListenerSocket.close();
                    firstTimeLeader = true;
                    System.out.println("**********************SYNC LISTENER SOCKET CLOSED");
                    synchronized (state) {
                        System.out.println("Newer leader discovered -> Turning FOLLOWER");
                        state.setLeaderId(-1);
                        state.setCurrentState(0);
                    }
                    
                    //System.out.println("---------------------");
                    //
                    
                    
                }
                
                
            }
            
        } catch (IOException ex) {
            Logger.getLogger(HeartbeatListener.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            Logger.getLogger(HeartbeatListener.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
