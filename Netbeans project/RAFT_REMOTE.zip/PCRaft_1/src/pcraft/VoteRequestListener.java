/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Giacomo
 */
public class VoteRequestListener extends Thread {

    private final static int VoteRequestPort = 9091;
    private final static int VoteReplyPort = 9092;
    private NodeState state;

    public VoteRequestListener(NodeState s) {
        this.state = s;
    }

    @Override
    public void run() {
        int timeout = 0;
        int timeoutCounter = 0;
        boolean firstTimeLeader = true;
        boolean firstTimeCandidate = true;
        try {
            ServerSocket listener = new ServerSocket(VoteRequestPort);
            System.out.println("Server #" + state.getNodeId() + " ready... listening for VoteRequest");
            while (true) {
                firstTimeLeader = firstTimeCandidate = true;
                try {
                    Socket socket = listener.accept();
                    Object obj = Receiver.receive(socket);
                    if (obj instanceof VoteRequest) {
                        VoteRequest request = (VoteRequest) obj;
                        VoteReply reply;
                        int votedFor = state.getVotedFor();
                        System.out.println("VoteRequest when votedFor: "+votedFor);
                        if (votedFor == -1 || votedFor == state.getLeaderId()) {  //not yet voted
                            reply = new VoteReply(state.getCurrentTerm(), true, state.getNodeId());
                            state.setVotedFor(request.getCandidateId());        //i voted for him
                        } else {
                            reply = new VoteReply(state.getCurrentTerm(), false, state.getNodeId());
                        }
                        System.out.println("VoteRequest received node (" + request.getCandidateId() + ") vote -> " + reply.isVoteGranted()+"\tRequesterNode is in term "+request.getTerm());
                        Sender.send(state.addresses[request.getCandidateId()], VoteReplyPort, reply);
                    }

                } catch (SocketTimeoutException ex) {
                    System.out.println("#" + timeoutCounter + " Timeout (" + timeout + " msec elapsed) -> BECOMING CANDIDATE");
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(HeartbeatListener.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(VoteRequestListener.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

        } catch (IOException ex) {
            Logger.getLogger(HeartbeatListener.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
