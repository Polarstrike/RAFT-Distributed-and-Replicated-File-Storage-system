/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.Serializable;

/**
 *
 * @author Giacomo
 */
public class VoteReply implements Serializable{
    
    private final int term;
    private final boolean voteGranted;
    private final int senderId;
    
    public VoteReply(int t, boolean vote, int id){
        this.term = t;
        this.voteGranted = vote;
        this.senderId = id;
    }

    public int getTerm() {
        return term;
    }

    public boolean isVoteGranted() {
        return voteGranted;
    }

    public int getSenderId() {
        return senderId;
    }
 
    
}
