/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Giacomo
 */
public class LeaderSyncListener extends Thread{
    private final static int LeaderSyncPort = 9095;
    private final NodeState state;
    private final ServerSocket listener;
    
    public LeaderSyncListener(NodeState s, ServerSocket listener){
        this.state = s;
        this.listener = listener;
    }
    
    @Override
    public void run(){
            System.out.println("Server #"+state.getNodeId()+" ready... LeaderSyncListener spawned");
            Semaphore syncSemaphore = null;
            while(true){
                try{
                    System.out.println("Waiting for a Follower to sync.....");
                    Socket socket = listener.accept();
                    System.out.println("FOLLOWER ASKED SYNC");
                    Object obj = Receiver.receive(socket);
                    if (obj instanceof AskLeaderObject) {
                        AskLeaderObject req = (AskLeaderObject) obj;
                        if (req.getOPCODE() == 5) {                       //SYNC OPCODE
                            //LOCK ALL CLIENT's REQUEST of WRITE OPERATION
                            syncSemaphore = state.getSyncSemaphore();
                            syncSemaphore.acquire();
                            System.out.println("\tClient writes are now blocked until sync is done.");

                            
                            int j=-1;
                            for (int i= 0; i < state.N_nodes; i++) {
                                //System.out.println("#"+i+"\tcomparing st "+state.addresses[i]+" with "+req.getSenderIP()+"\t"+req.getSenderIP().equals(state.addresses[i]));
                                if (req.getSenderIP().equals(state.addresses[i])) {
                                    j = i;
                                }
                            }

                            System.out.println("Follower " + j + " ask FILE SYNC, missing:");
                            List<FileState> nodeList = req.getFileStates();

                            FileState tmp;
                            for (int i = 0; i < nodeList.size(); i++) {
                                tmp = nodeList.get(i);
                                Date date = new Date(tmp.getTimestamp());
                                System.out.println("\t" + tmp.getFileName() + "\t" + tmp.getTimestamp() + "\t" + date);
                            }
                            System.out.println("-----------Here at leader---------");
                            List<FileState> atLeaderList = state.getFileStates();
                            for (int i = 0; i < atLeaderList.size(); i++) {
                                tmp = atLeaderList.get(i);
                                Date date = new Date(tmp.getTimestamp());
                                System.out.println("\t" + tmp.getFileName() + "\t" + tmp.getTimestamp() + "\t" + date);
                            }
                            System.out.println("----------------------------------");

//for loop sending all missing files to new follower 
                            for(int i = 0; i < nodeList.size(); i++){
                                tmp = nodeList.get(i);
                                System.out.println("#"+i+ " Sending to follower file " + tmp.getFileName());
                                //send file
                                
                                Sender.sendFileTo(socket, state.getDir(), tmp.getFileName(), tmp.getFileSize());
                            
                                System.out.println("#"+i+ " File "+tmp.getFileName()+" sent to follower\t(SYNC)");
                            }
                            
                            System.out.println("SYNC procedure completed, follower is now in SYNC");
                            
                            
//UNLOCK CLIENT's REQUEST of WRITE OPERATION
                            syncSemaphore.release();
                            System.out.println("\tClient writes are now re-enabled.");
                        }
                    }
                } catch (SocketException ex){
                    Logger.getLogger(LeaderSyncListener.class.getName()).log(Level.SEVERE, null, ex);
                    System.out.println("Quitting LeaderSyncListener");
                    if(syncSemaphore!=null)
                        syncSemaphore.release();
                    return;
                } catch (IOException ex) {
                    Logger.getLogger(LeaderSyncListener.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(LeaderSyncListener.class.getName()).log(Level.SEVERE, null, ex);
                } catch (InterruptedException ex) {
                    Logger.getLogger(LeaderSyncListener.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        
       
    }       
    
}
