/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Giacomo
 */
public class AskList extends Thread{
    
    String[] addresses;
    private final String myIp;
    private final int ClientPort = 9093;
    private final int leaderId;
    private AskLeaderObject ask;
    
    public AskList(String myIp, int leaderId, String[] addresses){
        this.myIp = myIp;        
        this.leaderId = leaderId;
        this.ask = null;
        this.addresses = addresses;
    }
    
    public AskList(String myIp, int leaderId, AskLeaderObject ask, String[] addresses){
        this.myIp = myIp;        
        this.leaderId = leaderId;
        this.ask = ask;
        this.addresses = addresses;
    }
    
    @Override
    public void run(){
        try {
            AskLeaderObject req = new AskLeaderObject(3, myIp);
            System.out.println("-----------------------LS-----------------------");
            System.out.println("Asking ls to node "+leaderId+" (leader) at "+addresses[leaderId]+":"+ClientPort);
            Socket socket = new Socket(addresses[leaderId], ClientPort);
            Sender.send(socket, req);
            
            Object obj = Receiver.receive(socket);
            if(obj instanceof AskLeaderObject){
                req = (AskLeaderObject) obj;
                if(req.getLeaderId() == -1){
                    System.out.println("Node is a Candidate... quitting");
                    socket.close();
                    return;
                }
                else{
                    List<FileState> fileStates = req.getFileStates();
                    if(ask != null)
                        ask.setFileStates(fileStates);
                    FileState tmp;
                    System.out.println("\nLeader ("+leaderId+") is alive, files are:");
                    for(int i=0; i<fileStates.size(); i++){
                        tmp = fileStates.get(i);
                        Date date = new Date(tmp.getTimestamp());
                        System.out.println("\t" + tmp.getFileName() + "\t("+tmp.getFileSize()+" bytes)\t" + date);// + "\t" + date.getTime());
                    }
                    System.out.println("------------------------------------------------");
                    socket.close();
                    return;
                }
            }                
            
        } catch (SocketTimeoutException ex){
            System.out.println("Node " + leaderId + " is down... ");            
        } catch (IOException ex) {
            System.out.println("No answer from node "+leaderId);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AskLeader.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
