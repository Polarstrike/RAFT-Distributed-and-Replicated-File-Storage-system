/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Giacomo
 */
public class AskLeaderObject implements Serializable{
    private int OPCODE;                 //0 ask leader Id;  1 ReadFile;     //2 WriteFile  
    private int leaderId; 
    private long lastModified;
    private final String senderIP;
    private boolean allowed;
    private String fileName;
    private long fileSize;
    private List<FileState> fileStates;
    
    public AskLeaderObject(int opCode, String clientIp){
        this.senderIP = clientIp;
        this.OPCODE = opCode;
        this.allowed = true;
        fileName = null;
        fileStates = new ArrayList<FileState>();
        this.lastModified = 0;
    }
    public AskLeaderObject(int opCode, String clientIp, String filename){
        this.senderIP = clientIp;
        this.OPCODE = opCode;
        this.allowed = true;
        this.fileName = filename;
        fileStates = new ArrayList<FileState>();
        this.lastModified = 0;
    }
    
    public AskLeaderObject(int opCode, String clientIp, String filename, long lastModified){
        this.senderIP = clientIp;
        this.OPCODE = opCode;
        this.allowed = true;
        this.fileName = filename;
        fileStates = new ArrayList<FileState>();
        this.lastModified = lastModified;
    }

    public int getLeaderId() {
        return leaderId;
    }

    public void setLeaderId(int leaderId) {
        this.leaderId = leaderId;
    }

    public String getSenderIP() {
        return senderIP;
    }

    public int getOPCODE() {
        return OPCODE;
    }

    public void setOPCODE(int OPCODE) {
        this.OPCODE = OPCODE;
    }

    public boolean isAllowed() {
        return allowed;
    }

    public void setAllowed(boolean allowed) {
        this.allowed = allowed;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public List<FileState> getFileStates() {
        return fileStates;
    }

    public void setFileStates(List<FileState> fileStates) {
        this.fileStates = fileStates;
    }

    public long getLastModified() {
        return lastModified;
    }

    public void setLastModified(long lastModified) {
        this.lastModified = lastModified;
    }

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }
    
    
    
    
}
