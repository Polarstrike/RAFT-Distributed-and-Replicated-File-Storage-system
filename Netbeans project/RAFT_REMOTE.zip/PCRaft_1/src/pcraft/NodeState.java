/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.Semaphore;

/**
 *
 * @author Giacomo
 */
public class NodeState {
    //addresses
    String[] addresses;    
    InetAddress nodeAddress;
    int N_nodes;
    private String dir;
    private File directory;
    
    //general
    volatile private int nodeId, currentTerm, currentState, leaderId;
    volatile private List<FileState> fileStates;
    //sync purpose
    private final Semaphore syncSemaphore;
    private final Semaphore rMutex;
    private int readCount;
 
    
    //election purpose
    volatile private int votedFor, obtainedVote;

    public NodeState(int id, int n) throws UnknownHostException, FileNotFoundException{
        nodeId = id;
        N_nodes = n;
        currentTerm = currentState = 0;
        leaderId = -1;
        votedFor = -1;
        obtainedVote = 0;
        syncSemaphore = new Semaphore(1);
        rMutex = new Semaphore(1);
        readCount = 0;
        addresses = new String[N_nodes];
        
        Scanner s = new Scanner(new File("ClusterAddresses.txt"));    
        System.out.println("Addresses: ");    
        for(int i=0; i<N_nodes; i++){
            addresses[i] = s.nextLine();      
            System.out.println("#"+i+"\t"+addresses[i]);
        }
        s.close();        
        nodeAddress = InetAddress.getByName(addresses[nodeId]);
        
        //Shared directory
        //File f = new File("c:/raftShared/");
        //f.mkdir();
        dir = "node" + nodeId + "/";
        directory = new File(dir);
        directory.mkdir();
        
        //empty tmp/ directory
        File t = new File(dir + "tmp/");
        t.mkdir();
        File[] listOfTmpFiles = t.listFiles();
        if(listOfTmpFiles != null)
            for(File ff : listOfTmpFiles)
                ff.delete();
        
        System.out.println("------------- Directory "+dir+" content -------------");
        File[] listOfFiles = directory.listFiles();        
        fileStates = new ArrayList<FileState>();
        for (int i = 0; i < listOfFiles.length; i++) {
            if (listOfFiles[i].isFile()) {
                long timestamp = listOfFiles[i].lastModified();
                Date date = new Date(timestamp);
                System.out.println("File " + listOfFiles[i].getName() + "\t\tLast modified: " + date + "\t" + timestamp);
                fileStates.add(new FileState(listOfFiles[i].getName(), timestamp, listOfFiles[i].length()));
            } 
        }        
        /*
        System.out.print("\nFileList: ");
        for(int i=0; i<fileStates.size(); i++)
            System.out.print(fileStates.get(i).getFileName() + "  ");
        */
        System.out.println("---------------------------------------------------\n");
    }
    
    public void outAddr(){
        for(int i=0; i<N_nodes; i++){     
            System.out.println("#"+i+"\t"+addresses[i]);
        }
    }
    
    public synchronized void updateFileStates(){
        File[] listOfFiles = directory.listFiles();        
        fileStates = new ArrayList<FileState>();
        for (int i = 0; i < listOfFiles.length; i++) {
            if (listOfFiles[i].isFile()) {
                long timestamp = listOfFiles[i].lastModified();
                fileStates.add(new FileState(listOfFiles[i].getName(), timestamp, listOfFiles[i].length()));
            } 
        }
    }

    public synchronized List<FileState> getFileStates() {
        return fileStates;
    }
    
    public synchronized int getNodeId() {
        return nodeId;
    }

    
    
    public synchronized void setNodeId(int nodeId) {
        this.nodeId = nodeId;
    }

    public synchronized int getCurrentTerm() {
        return currentTerm;
    }

    public synchronized void setCurrentTerm(int currentTerm) {
        this.currentTerm = currentTerm;
    }

    public synchronized int getCurrentState() {
        return currentState;
    }

    public synchronized void setCurrentState(int currentState) {
        this.currentState = currentState;
    }

    public synchronized int getLeaderId() {
        return leaderId;
    }

    public synchronized void setLeaderId(int leaderId) {
        this.leaderId = leaderId;
    }

    public synchronized int getVotedFor() {
        return votedFor;
    }

    public synchronized void setVotedFor(int votedFor) {
        this.votedFor = votedFor;
    }

    public synchronized int getObtainedVote() {
        return obtainedVote;
    }

    public synchronized void setObtainedVote(int obtainedVote) {
        this.obtainedVote = obtainedVote;
    }
    
    public synchronized void becomeCandidate(){
        //increase term, vote for my self
        currentTerm++;
        votedFor = nodeId;
        obtainedVote = 1;
        
    }
    
    public synchronized void restoreElection(){
        votedFor = -1;
        obtainedVote = 0;
    }
    
    public synchronized void incrementObtainedVote(){
        obtainedVote++;
    }

    public String getDir() {
        return dir;
    }

    public void setDir(String dir) {
        this.dir = dir;
    }

    public File getDirectory() {
        return directory;
    }

    public void setDirectory(File directory) {
        this.directory = directory;
    }

    public Semaphore getSyncSemaphore() {
        return syncSemaphore;
    }

    public Semaphore getrMutex() {
        return rMutex;
    }

    public int getReadCount() {
        return readCount;
    }

    public void setReadCount(int readCount) {
        this.readCount = readCount;
    }
    
    
    
    
}
