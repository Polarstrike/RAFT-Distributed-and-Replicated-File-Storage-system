/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Giacomo
 */
public class Receiver {

    public static Object receive(Socket socket) throws IOException, ClassNotFoundException {
        InputStream is = socket.getInputStream();
        ObjectInputStream ois = new ObjectInputStream(is);
        
        Object obj = ois.readObject();
        if (obj == null) {
            System.out.println("null");
        }
        //is.close();
        //socket.close();
        return obj;
    }

    
    public static void receiveFileFrom(Socket socket, String filePath, String fileName, long fileSize){
        int n;
        try {
            byte[] buffer = new byte[1024];

            File f = new File(filePath);
            f.mkdir();
            filePath = filePath + fileName;
            FileOutputStream fos = new FileOutputStream(filePath);
            System.out.println("Receiving file to:\t"+filePath+" ("+fileSize+")");
            DataInputStream is = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
            //InputStream is = socket.getInputStream();            
            
            while (fileSize > 0 && (n = is.read(buffer, 0, (int) Math.min(buffer.length, fileSize))) != -1) {
                fos.write(buffer, 0, n);
                fileSize -= n;
            }
            
            fos.close();
    
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Sender.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Sender.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
