/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.File;
import java.io.IOException;
import java.net.Socket;

/**
 *
 * @author Giacomo Pellicci
 */
public class ClientWriteFile extends Thread {

    String[] addresses = new String[]{"127.0.0.1", "127.0.0.2", "127.0.0.3", "127.0.0.4", "127.0.0.5"};
    private final String myIp;
    private final int ClientPort = 9093;
    private int leaderId;
    private final String SERVER;
    private final String dir;
    private String fileName;

    public ClientWriteFile(String myIp, int leaderId, String filePath, String fileName) {
        this.myIp = myIp;
        this.leaderId = leaderId;
        this.SERVER = addresses[leaderId];
        this.dir = filePath;
        this.fileName = fileName;

    }

    @Override
    public void run() {
        try {
            System.out.println("----------------------WRITE----------------------");
            File f = new File(dir + fileName);
            if (!f.isFile()) {
                System.err.println(fileName + " does not exists on the client");
                return;
            }
            AskLeaderObject request = new AskLeaderObject(2, myIp, fileName);     //writeRequest
            request.setFileSize(f.length());
            System.out.println("Asking to node " + leaderId + " at " + SERVER + ":" + ClientPort + " to write " + fileName);
            
            
            Socket socket = new Socket(addresses[leaderId], ClientPort);            
            Sender.send(socket, request);           //send readRequest            

            Object obj = Receiver.receive(socket);
            if (obj instanceof AskLeaderObject) {         //received reply from node
                request = (AskLeaderObject) obj;
                if (request.isAllowed()) {                //i have contacted the leader
                    System.out.println("Uploading to Leader, operation ALLOWED");
                    //DOWNLOAD
                    Sender.sendFileTo(socket, dir, fileName, f.length());
                    
                    obj = Receiver.receive(socket);
                    if (obj instanceof AskLeaderObject) {
                        request = (AskLeaderObject) obj;
                        if(request.getOPCODE() == 1){
                            System.out.println("Write operation completed! "+fileName+" is now in sync over the cluster");
                        }
                        else{
                            System.err.println("Something went wrong with the write. Data not stored (cluster not reliable)");;
                        }
                    }
                } else {           //operation DENIED
                    if(request.getOPCODE() == -2){
                        System.out.println("\t*****CLUSTER SYNC in progress, retry later");
                    }
                    else
                        System.out.println("I haven't contacted the leader, operation DENIED");
                }
            }
            System.out.println("-------------------------------------------------");
            socket.close();
            
        } catch (IOException | ClassNotFoundException ex) {
            System.err.println("Operation not performed.");
            //Logger.getLogger(ClientReadFile.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    
}
