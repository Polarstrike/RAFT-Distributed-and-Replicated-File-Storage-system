/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;

/**
 *
 * @author Giacomo
 */
public class Sender {

    public static Socket send(String nodeAddress, int port, Object obj) throws IOException {
        Socket socket = new Socket(nodeAddress, port);
        OutputStream os = socket.getOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(os);
        oos.writeObject(obj);
        //oos.close();
        //os.close();
        //socket.close();
        return socket;
    }
    
    public static void send(Socket socket, Object obj) throws IOException {
        OutputStream os = socket.getOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(os);
        oos.writeObject(obj);
        //oos.close();
        //os.close();
        //socket.close();
    }
    
    public static Socket send(String nodeAddress, int port, Object obj, boolean mode) throws SocketTimeoutException, IOException {
        int timeout = 0;
        if (mode) {
            timeout = 300;
        }
        Socket socket = new Socket();
        socket.connect(new InetSocketAddress(nodeAddress, port), timeout);       //30sec timeout
        socket.setSoTimeout(timeout);                                            //30sec on subsequent request (useless?)
        OutputStream os = socket.getOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(os);
        oos.writeObject(obj);
        //oos.close();
        //os.close();
        //socket.close();
        return socket;
    }
    
    public static void send(Socket socket, Object obj, boolean mode) throws SocketTimeoutException, IOException {
        int timeout = 0;
        if (mode) {
            timeout = 5000;
        }
        socket.setSoTimeout(timeout);                                            //30sec on subsequent request (useless?)
        OutputStream os = socket.getOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(os);
        oos.writeObject(obj);
        //oos.close();
        //os.close();
        //socket.close();
    }
    
    public static void sendFileTo(Socket socket, String filePath, String fileName, long fileSize) throws IOException {
        int n;
        try {
            String path = filePath + fileName;

            System.out.println("Sending " + path + "(" + fileSize + " bytes)");
            // send file
            byte[] buffer = new byte[1024];

            DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
            FileInputStream fis = new FileInputStream(new File(path));      //this can throw file not found exception

            while ((n = fis.read(buffer)) != -1) {
                dos.write(buffer, 0, n);
                dos.flush();
            }

            fis.close();

            System.out.println("File " + path + " correctly sent.");

        } catch (FileNotFoundException ex) {
            System.out.println("File does not exist");
        }

    }

}
