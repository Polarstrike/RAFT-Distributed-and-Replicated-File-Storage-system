/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Giacomo Pellicci
 */
public class ClientWriteFile extends Thread {

    private String[] addresses;
    private final String myIp;
    private final int ClientPort = 9093;
    private int leaderId, N_Nodes;
    private final String SERVER;
    private final String dir;
    private String fileName;

    public ClientWriteFile(String myIp, int leaderId, String filePath, String fileName, int n, String[] addresses) {
        this.myIp = myIp;
        this.leaderId = leaderId;
        this.SERVER = addresses[leaderId];
        this.dir = filePath;
        this.fileName = fileName;
        this.N_Nodes = n;
        this.addresses = new String[N_Nodes];
        this.addresses = addresses;

    }

    @Override
    public void run() {
        try {
            File f = new File(dir + fileName);
            if (!f.isFile()) {
                System.err.println(fileName + " does not exists on the client");
                return;
            }
            AskLeaderObject request = new AskLeaderObject(2, myIp, fileName);     //writeRequest
            request.setFileSize(f.length());
            System.out.println("Asking to node " + leaderId + " at " + SERVER + ":" + ClientPort + " to write " + fileName);
            
            
            Socket socket = new Socket(addresses[leaderId], ClientPort);            
            Sender.send(socket, request);           //send readRequest            

            Object obj = Receiver.receive(socket);
            if (obj instanceof AskLeaderObject) {         //received reply from node
                request = (AskLeaderObject) obj;
                if (request.isAllowed()) {                //i have contacted the leader
                    System.out.println("Uploading to Leader, operation ALLOWED");
                    //DOWNLOAD
                    Sender.sendFileTo(socket, dir, fileName, f.length());
                    
                    obj = Receiver.receive(socket);
                    if (obj instanceof AskLeaderObject) {
                        request = (AskLeaderObject) obj;
                        if(request.getOPCODE() == 1){
                            System.out.println("Write operation completed! "+fileName+" is now in sync over the cluster");
                        }
                        else{
                            System.err.println("Something went wrong with the write. Data not stored (cluster not reliable)");;
                        }
                    }
                } else {           //operation DENIED
                    if(request.getOPCODE() == -2){
                        System.out.println("\t*****CLUSTER SYNC in progress, retry later");
                    }
                    else
                        System.out.println("I haven't contacted the leader, operation DENIED");
                }
            }
            socket.close();
            
        } catch (IOException | ClassNotFoundException ex) {
            System.err.println("Operation not performed.");
            //Logger.getLogger(ClientReadFile.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    
}
