/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.InetAddress;
import java.util.Scanner;

/**
 *
 * @author Giacomo
 */
public class PCRaftClient {

    public static void main(String[] args) throws InterruptedException, FileNotFoundException {
        
        String nodeIp = "127.0.0.35";
        String clientDir = args[0];
        int N_nodes = Integer.parseInt(args[1]);
        
        String[] addresses = new String[N_nodes];
        int leader;
        
        File directory = new File(clientDir+"shared/");
        directory.mkdir();

        
        Scanner s = new Scanner(new File(clientDir+"ClusterAddresses.txt"));    
        System.out.println("Addresses: ");    
        for(int i=0; i<N_nodes; i++){
            addresses[i] = s.nextLine();      
            System.out.println("#"+i+"\t"+addresses[i]);
        }
        s.close(); 
        clientDir = clientDir+"shared/";
        
        
        
        
        
        
        
        AskLeaderObject ask = new AskLeaderObject(0, nodeIp);
        ask.setLeaderId(-1);
        AskLeader a = new AskLeader(N_nodes, nodeIp, ask, addresses);
        a.start();
        a.join();
        //System.out.println("Thread told me that leader is " + ask.getLeaderId());
        leader = ask.getLeaderId();
        
        
        /*
        if (leader != -1) {
            ClientReadFile r = new ClientReadFile(nodeIp, leader, clientDir, "adolfo.c", N_nodes, addresses);
            r.start();
            r.join();
        }
        
        
        */
        if (leader != -1) {
            ClientWriteFile w = new ClientWriteFile(nodeIp, leader, clientDir,"papera.png", N_nodes, addresses);
            w.start();
            w.join();
        }
        
        
        //leader = 0;
        if (leader != -1) {
            AskList ls = new AskList(nodeIp, leader, addresses);
            ls.start();
            ls.join();
        }
        
    }

}
