/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.Serializable;
import java.util.Objects;

/**
 *
 * @author Giacomo
 */
public class FileState implements Serializable{
    
    private final String fileName;
    private final long fileSize;
    private final long timestamp;
    public FileState(String fileName, long timestamp, long fileSize){
        this.fileName = fileName;
        this.timestamp = timestamp;
        this.fileSize = fileSize;
    }
    
    @Override
    public boolean equals(Object obj){
        // If the object is compared with itself then return true   
        if (obj == this) { 
            return true; 
        } 
  
        /* Check if o is an instance of Complex or not 
          "null instanceof [type]" also returns false */
        if (!(obj instanceof FileState)) { 
            return false; 
        } 
          
        // typecast o to Complex so that we can compare data members  
        FileState c = (FileState) obj; 
          
        // Compare the data members and return accordingly  
        return (c.getFileName().equals(this.getFileName()) && c.getTimestamp() == this.getTimestamp()); 
    }
    
    public String getFileName() {
        return fileName;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public long getFileSize() {
        return fileSize;
    }
    
    
    
}
