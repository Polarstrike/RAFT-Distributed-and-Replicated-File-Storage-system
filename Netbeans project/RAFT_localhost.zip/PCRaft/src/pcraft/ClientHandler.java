/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Giacomo
 */
public class ClientHandler extends Thread{
    private final static int ClientPort = 9093;    
    private final static int FileTransferPort = 9094;

    private final NodeState state;
    
    public ClientHandler(NodeState s){
        this.state = s;
    }
    
    @Override
    public void run(){        
        try {
            System.out.println("Listening Clients on " + state.nodeAddress + ":" + ClientPort);
            ServerSocket listener = new ServerSocket(ClientPort, 50, state.nodeAddress);
            while (true) {
                Socket socket = listener.accept();
                ClientOperationThread op = new ClientOperationThread(state, socket);
                op.start();
            }
        } catch (IOException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
  
}
