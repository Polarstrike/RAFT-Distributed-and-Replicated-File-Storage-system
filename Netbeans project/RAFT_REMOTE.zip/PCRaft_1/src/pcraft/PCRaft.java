/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.IOException;
import java.net.UnknownHostException;

/**
 *
 * @author Giacomo
 */
public class PCRaft {

    /**
     * HOLD ON
     */
    public static void main(String[] args) throws UnknownHostException, InterruptedException, IOException { 
        System.out.println("id "+args[0] +"\tlen "+args.length);
        int id = Integer.parseInt(args[0]);        
        
        int firstOn = 1;
        if(args.length != 1){
            System.out.println("arg2: "+args[1]);
            firstOn = 0;
        }
        
        int N_nodes = 3;
        NodeState state = new NodeState(id, N_nodes);
        
        //Thread.sleep(500000);
        String nodeIp = state.addresses[state.getNodeId()];
        
        if(!(id == 0 && firstOn == 0)){        
            FollowerSyncRequest syncRequest = new FollowerSyncRequest(state);
            syncRequest.start();
            syncRequest.join();
        }
        
        
        
        
        
        if(id == 0 && firstOn == 0){
            state.setCurrentState(2);       //node 0 on first boot is leader
            state.setLeaderId(id);
            state.setVotedFor(id);
        }
        
        
        HeartbeatListener l = new HeartbeatListener(state);
        VoteRequestListener v = new VoteRequestListener(state);
        ClientHandler c = new ClientHandler(state);
        l.start();
        v.start();
        c.start();
    }
    
}
