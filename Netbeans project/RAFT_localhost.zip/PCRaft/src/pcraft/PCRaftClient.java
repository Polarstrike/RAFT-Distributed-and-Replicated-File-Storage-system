/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.File;

/**
 *
 * @author Giacomo
 */
public class PCRaftClient {

    public static void main(String[] args) throws InterruptedException {
        String nodeIp = "127.0.0.35";
        String clientDir = "c:/raftShared/client/";
        int N_nodes = 3;
        int leader;
        
        File f = new File("c:/raftShared/");
        f.mkdir();
        File directory = new File(clientDir);
        directory.mkdir();

        
        AskLeaderObject ask = new AskLeaderObject(0, nodeIp);
        ask.setLeaderId(-1);
        AskLeader a = new AskLeader(N_nodes, nodeIp, ask);
        a.start();
        a.join();
        //System.out.println("Thread told me that leader is " + ask.getLeaderId());
        leader = ask.getLeaderId();
        
        
        
        if (leader != -1) {
            ClientReadFile r = new ClientReadFile(nodeIp, leader, clientDir, "source.pdf");
            r.start();
            r.join();
        }
        
        
        
        if (leader != -1) {
            ClientWriteFile w = new ClientWriteFile(nodeIp, leader, clientDir,"file.c");
            w.start();
            w.join();
        }
        
        
        //leader = 0;
        if (leader != -1) {
            AskList ls = new AskList(nodeIp, leader);
            ls.start();
            ls.join();
        }
        
    }

}
