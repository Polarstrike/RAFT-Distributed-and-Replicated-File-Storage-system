/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.File;
import java.io.IOException;
import java.net.ConnectException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileTime;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Giacomo
 */
public class ClientOperationThread extends Thread {

    private final static int FileTransferPort = 9094;
    private NodeState state;
    private Socket socket;

    public ClientOperationThread(NodeState s, Socket sock) {
        this.state = s;
        this.socket = sock;
    }

    @Override
    public void run() {
        try {
            //receive command
            Object obj = Receiver.receive(socket);
            
            if (obj instanceof AskLeaderObject) {
                AskLeaderObject reply = (AskLeaderObject) obj;
                int operation = reply.getOPCODE();
                
                //CLIENT IS ASKING FOR LEADER ID always allowed
                if (operation == 0) {
                    try{
                        System.out.println("Client " + reply.getSenderIP() + " requested operation LEADER ID");
                        if (state.getCurrentState() != 1) {
                            reply.setLeaderId(state.getLeaderId());
                        } else {
                            reply.setLeaderId(-1);
                        }
                        Sender.send(socket, reply);
                        System.out.println("LEADER ID DONE");
                    } catch (IOException ex){
                        System.err.println("LeaderId exception");
                    }
                } 
                
                //CLIENT IS ASKING FOR READ OPERATION  only allowed if leader
                else if (operation == 1) {                    
                    Semaphore rMutex = state.getrMutex();
                    Semaphore writeSync = state.getSyncSemaphore();
                    
                    
                    
                    
                    try{
                        System.out.println("Client " + reply.getSenderIP() + " requested operation READ");
                        if (state.getCurrentState() != 2) {           //i am not the leader, i'm telling the client who is
                            reply.setLeaderId(state.getLeaderId());
                            reply.setAllowed(false);
                            Sender.send(socket, reply);
                        } else {   //read operation is allowed
                            
                            rMutex.acquire();
                            state.setReadCount(state.getReadCount() + 1);
                            if(state.getReadCount() == 1)
                                writeSync.acquire();
                            rMutex.release();
                            
                            String fileName = reply.getFileName();
                            File f = new File(state.getDir() + fileName);
                            System.out.println("Client is asking for " + state.getDir() + fileName);
                            if (!f.isFile()) {     //if the requested file is not actually a file in my node (aka DO NOT exists)
                                fileName = null;
                                reply.setFileName(null);
                            }

                            reply.setFileSize(f.length());
                            Sender.send(socket, reply);
                            if (fileName != null) {       //give the file to the client
                                System.out.println("File exist on the server -> SENT");
                                Sender.sendFileTo(socket, state.getDir(), fileName, f.length());
                                //replyReadRequest(listener, fileName);
                            } else {       //nothing to do
                                System.out.println("File does not exist");

                            }
                            
                            
                            rMutex.acquire();
                            state.setReadCount(state.getReadCount() - 1);
                            if(state.getReadCount() == 0)
                                writeSync.release();
                            rMutex.release();
                            
                            
                        }
                    } catch (IOException ex){
                        System.err.println("READ exception");
                    }
                    
                } //Write operation only allowed if leader
                else if (operation == 2) {
                    try {
                        Semaphore clientWriteSem = state.getSyncSemaphore();
                        System.out.println("Client " + reply.getSenderIP() + " requested operation WRITE of file " + reply.getFileName() + "\t size of " + reply.getFileSize());
                        if (state.getCurrentState() != 2) {           //i am not the leader, i'm telling the client who is
                            reply.setLeaderId(state.getLeaderId());
                            reply.setAllowed(false);
                            Sender.send(socket, reply);
                        } else {   //write operation is allowed
                            String fileName = reply.getFileName();
                            long fileSize = reply.getFileSize();

                            if (clientWriteSem.tryAcquire()) {    //no sync operation ongoing right now
                                Sender.send(socket, reply);       //Going to write
                                //Time to receive the file from the client
                                Receiver.receiveFileFrom(socket, state.getDir() + "tmp/", fileName, fileSize);
                                System.out.println("File received from client. Replication in progress: Sending file to followers");

                                //1) Send file to all followers 1thread each?
                                int count = 1;
                                //LAST MODIFIED UPDATED FOR THE FILE
                                FileTime timestamp = FileTime.from(Instant.now());
                                long lastModified = timestamp.toMillis();
                                Files.setLastModifiedTime(Paths.get(state.getDir() + "tmp/" + fileName), timestamp);
                                ServerSocket fileListenerLeader = new ServerSocket(FileTransferPort);
                                Socket[] sockets = new Socket[state.N_nodes];
                                for (int i = 0; i < state.N_nodes; i++) {
                                    if (i != state.getNodeId()) {
                                        AskLeaderObject req = new AskLeaderObject(0, null, fileName, lastModified);
                                        try {
                                            sockets[i] = new Socket(state.addresses[i], FileTransferPort);
                                            req.setFileSize(fileSize);
                                            Sender.send(sockets[i], req);
                                            Sender.sendFileTo(sockets[i], state.getDir() + "tmp/", fileName, fileSize);
                                            count++;
                                        } catch (ConnectException ex) {
                                            System.out.println("\tNode " + i + " fileTransfer impossible (DOWN)");
                                        }
                                    }
                                }
                                
                                fileListenerLeader.close();
                                //2) Check if majority have received it
                                AskLeaderObject req;
                                System.out.print(count + "/" + state.N_nodes + " nodes obtained the file");
                                Path source = Paths.get(state.getDir() + "tmp/" + fileName);
                                AskLeaderObject replyClient = new AskLeaderObject(0, state.addresses[state.getNodeId()]);
                                if (count > (state.N_nodes / 2)) {
                                    System.out.println("\tMAJORITY REACHED");
                                    //3) Copy file from tmp directory to shared directory
                                    Path dest = Paths.get(state.getDir() + fileName);
                                    Path result = Files.move(source, dest, StandardCopyOption.REPLACE_EXISTING);
                                    if (result.equals(dest)) {
                                        System.out.println("File moved to permanent directory. FileStates UPDATED");
                                        File ff = new File(state.getDir() + fileName);
                                        ff.setLastModified(lastModified);
                                        //4a) Tell them to copy the file from tmp directory to shared directory
                                        //OPCODE = 1 means commmit
                                        state.updateFileStates();
                                        req = new AskLeaderObject(1, null, fileName);
                                        replyClient.setOPCODE(1);   //Write gone good

                                    } else {
                                        //4b) Tell them to ABORT operation
                                        System.out.println("File failed to move!\t" + state.getNodeId());
                                        //OPCODE = 0 means abort
                                        req = new AskLeaderObject(0, null, fileName);
                                        replyClient.setOPCODE(0);   //Write gone bad
                                        Files.delete(source);
                                    }

                                } else {
                                    //4c) Tell them to ABORT operation
                                    System.out.println("\tMAJORITY NOT REACHED (ABORT)");
                                    //OPCODE = 0 means abort
                                    req = new AskLeaderObject(0, null, fileName);
                                    replyClient.setOPCODE(0);   //Write gone bad
                                    Files.delete(source);
                                }

                                
                                //5) sending commit/abort msg to all followers
                                int commitCount = 1;
                                for (int i = 0; i < state.N_nodes; i++) {
                                    if (i != state.getNodeId()) {
                                        try {
                                            if (req.getOPCODE() == 1) {
                                                System.out.println("Sending commit request to node " + i);
                                            } else {
                                                System.out.println("Sending abort request to node " + i);
                                            }
                                            if (sockets[i] != null) {
                                                Sender.send(sockets[i], req); 
                                                commitCount++;
                                            } else {
                                                System.out.println("\tNode " + i + " commitRequest impossible (DOWN)");
                                            }
                                        } catch (ConnectException ex) {
                                            System.out.println("\tNode " + i + " commitRequest impossible (DOWN)");
                                        }
                                    }
                                }
                                System.out.println("CommitCount: "+commitCount+"/"+state.N_nodes);
                                if(commitCount <= (state.N_nodes/2))
                                    replyClient.setOPCODE(0);
                                
//6) send operation result to client                                
                                try{
                                    Sender.send(socket, replyClient);
                                } catch (SocketException ex){
                                    System.err.println("Client is no more available, operation done (good or not)");
                                }
                                clientWriteSem.release();
                            } else {                               //sync operation is happening right now
                                System.out.println("Client write DENIED -> SYNC IN PROGRESS");
                                reply.setAllowed(false);
                                reply.setOPCODE(-2);
                                Sender.send(socket, reply);
                            }
                        }
                    } catch (SocketException ex) {
                        System.err.println("Sock exc -> ");
                    }
                } else if (operation == 3) {                //LS (LIST files)
                    try{
                        System.out.println("Client " + reply.getSenderIP() + " requested operation LS");
                        /*
                        if(state.getCurrentState() != 2){           //i am not the leader, i'm telling the client who is
                        reply.setLeaderId(state.getLeaderId());
                        reply.setAllowed(false);
                        Sender.send(reply.getSenderIP(), ClientPort, reply);
                        }
                        else{   //ls operation is allowed
                        */
                        List<FileState> ll = state.getFileStates();
                        reply.setFileStates(ll);

                        Sender.send(socket, reply);
                        System.out.println("LS operation completed");
                    } catch (IOException ex){
                        System.err.println("LS exception");
                    }
                } else if (operation == 4) {        //DELETE OPERATION
                    String deleteTarget = reply.getFileName();
                    File f = new File(state.getDir() + deleteTarget);
                    if(state.getCurrentState() == 2) {
                        reply.setAllowed(true);
                        if (f.delete()) {
                            System.out.println("File " + deleteTarget + " deleted.");
                            state.updateFileStates();
                            //keep same filename
                        } else {
                            reply.setFileName(null);
                            System.out.println("File " + deleteTarget + " not found.");
                        }
                    } 
                    else {
                        reply.setAllowed(false);
                    }
                    
                    Sender.send(socket, reply);
                        
                }

            }
            socket.close();
            
        } catch (IOException ex) {
            Logger.getLogger(ClientOperationThread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ClientOperationThread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            Logger.getLogger(ClientOperationThread.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
