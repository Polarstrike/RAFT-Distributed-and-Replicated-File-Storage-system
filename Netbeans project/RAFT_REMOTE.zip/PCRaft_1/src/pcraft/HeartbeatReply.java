/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.Serializable;

/**
 *
 * @author Giacomo
 */
public class HeartbeatReply implements Serializable{
    private int term;
    private boolean success;
    private int senderId;
    
    public HeartbeatReply(int t, boolean s, int id){
        this.term = t;
        this.success = s;
        this.senderId = id;
    }

    public int getTerm() {
        return term;
    }

    public void setTerm(int term) {
        this.term = term;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public int getSenderId() {
        return senderId;
    }

    public void setSenderId(int senderId) {
        this.senderId = senderId;
    }
    
}
