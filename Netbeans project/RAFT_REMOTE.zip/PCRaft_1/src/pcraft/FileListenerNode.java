/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Giacomo Pellicci
 */
public class FileListenerNode extends Thread{
    
    private final static int FileTransferPort = 9094;
    private final NodeState state;
    private ServerSocket listener;
    
    public FileListenerNode(NodeState s){
        this.state = s;
    }
    
    @Override
    public void run() {
        System.out.println("Server #" + state.getNodeId() + " ready... listening for leader filetransfer request");
        try {
            listener = new ServerSocket(FileTransferPort);
            while (true) {
//1) listen for leader to send me files
                emptyTmp();
                Socket socket;
                try {
                    socket = listener.accept();
                } catch (SocketException ex) {
                    System.out.println("FileListenerNode Thread asked to quit... quitting");
                    return;
                }

                try {
                    Object obj = Receiver.receive(socket);

//2) Wait file from Leader
                    if (obj instanceof AskLeaderObject) {
                        AskLeaderObject req = (AskLeaderObject) obj;
                        System.err.println("Leader want to replicate " + req.getFileName() + " of size " + req.getFileSize());

                        Receiver.receiveFileFrom(socket, state.getDir() + "tmp/", req.getFileName(), req.getFileSize());

                        File ff = new File(state.getDir() + "tmp/" + req.getFileName());
                        ff.setLastModified(req.getLastModified());

//3)Wait for commit/abort from leader
                        obj = Receiver.receive(socket);
                        if (obj instanceof AskLeaderObject) {
                            req = (AskLeaderObject) obj;

                            Path source = Paths.get(state.getDir() + "tmp/" + req.getFileName());
                            if (req.getOPCODE() == 1) {   //COMMIT
                                System.out.println("Leader told me to COMMIT " + req.getFileName());
                                //keep the same last modified of the leader
                                Path dest = Paths.get(state.getDir() + req.getFileName());

                                //Move to permanent dir. ( COMMIT )
                                Path result = Files.move(source, dest, StandardCopyOption.REPLACE_EXISTING);
//4a) COMMIT               
                                if (result.equals(dest)) {
                                    System.out.println("**COMMIT**\tFile " + req.getFileName() + " moved to permanent directory");

                                } else {
//4b) Error -> ABORT operation
                                    System.out.println("File failed to move! (deleted)");
                                    Files.delete(source);
                                }
                                state.updateFileStates();

                            } 
//4c) ABORT                            
                            else {
                                System.out.println("Leader told me to ABORT " + req.getFileName() + "(deleted)");
                                Files.delete(source);
                            }
                        }
                    }
                } catch (SocketException ex) {
                    //ABORT IF SOCKET EXCEPTION (leader is ded)
                    System.err.println("SOCK EXC");
                    emptyTmp();
                    
                }
            }
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(FileListenerNode.class.getName()).log(Level.SEVERE, null, ex);
        }
    } 

    public ServerSocket getListener() {
        return listener;
    }
    
    private void emptyTmp(){
        File f = new File(state.getDir() + "tmp/");
        f.mkdir();
        File[] listOfTmpFiles = f.listFiles();
        for (File ff : listOfTmpFiles) {
            ff.delete();
        }
    }
    
}
