/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.Serializable;

/**
 *
 * @author Giacomo
 */
public class FileRequest implements Serializable{
    private int mode, status;
    private String fileName;
    private String clientIp;
    
    
    public FileRequest(int mode, String fileName, String Ip){
        this.fileName = fileName;
        this.mode = mode;
        this.clientIp = Ip;
    }

    public String getClientIp() {
        return clientIp;
    }

    public void setClientIp(String clientIp) {
        this.clientIp = clientIp;
    }

    
    public int getMode() {
        return mode;
    }

    public void setMode(int mode) {
        this.mode = mode;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    
}
