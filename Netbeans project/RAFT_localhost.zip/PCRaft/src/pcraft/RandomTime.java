/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.util.Random;

/**
 *
 * @author Giacomo
 */
public class RandomTime {
    private static final int low = 150;
    private static final int high = 300;
    
    public static int electionTimeout(){
        Random r = new Random();
        return r.nextInt(high-low) + low;
    }
}
