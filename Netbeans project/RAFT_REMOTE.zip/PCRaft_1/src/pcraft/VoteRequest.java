/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.Serializable;

/**
 *
 * @author Giacomo
 */
public class VoteRequest implements Serializable{
    
    private int term, candidateId;
    
    public VoteRequest(int t, int candidateId){
        this.term = t;
        this.candidateId = candidateId;
    }

    public int getTerm() {
        return term;
    }

    public void setTerm(int term) {
        this.term = term;
    }

    public int getCandidateId() {
        return candidateId;
    }

    public void setCandidateId(int candidateId) {
        this.candidateId = candidateId;
    }
    
    
}
