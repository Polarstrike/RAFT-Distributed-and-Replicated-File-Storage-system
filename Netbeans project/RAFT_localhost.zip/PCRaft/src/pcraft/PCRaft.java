/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.IOException;
import java.net.UnknownHostException;

/**
 *
 * @author Giacomo
 */
public class PCRaft {

    /**
     * HOLD ON
     */
    public static void main(String[] args) throws UnknownHostException, InterruptedException, IOException {        
        int id = 2;
        int firstOn = 0;
        int N_nodes = 3;
        NodeState state = new NodeState(id, N_nodes);
        String nodeIp = state.addresses[state.getNodeId()];
        
        if(!(id == 0 && firstOn == 0)){        
            FollowerSyncRequest syncRequest = new FollowerSyncRequest(state);
            syncRequest.start();
            syncRequest.join();
        }
        
        
        
        
        
        if(id == 0 && firstOn == 0){
            state.setCurrentState(2);       //node 0 on first boot is leader
            state.setLeaderId(id);
            state.setVotedFor(id);
        }
        
        
        HeartbeatListener l = new HeartbeatListener(state);
        VoteRequestListener v = new VoteRequestListener(state);
        ClientHandler c = new ClientHandler(state);
        l.start();
        v.start();
        c.start();
    }
    
}
