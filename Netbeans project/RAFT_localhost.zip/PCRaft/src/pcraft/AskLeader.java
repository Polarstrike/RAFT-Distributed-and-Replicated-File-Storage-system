/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Giacomo
 */
public class AskLeader extends Thread{
    
    String[] addresses = new String[] {"127.0.0.1", "127.0.0.2", "127.0.0.3", "127.0.0.4", "127.0.0.5"};
    private final String myIp;
    private final int N_nodes;
    private final int ClientPort = 9093;
    private AskLeaderObject ask;
    
    
    public AskLeader(int n, String myIp, AskLeaderObject ask){
        this.N_nodes = n;
        this.myIp = myIp;
        this.ask = ask;
    }
    
    @Override
    public void run(){
        //ServerSocket listener = new ServerSocket(ClientPort, 50, InetAddress.getByName(myIp));
        
        System.out.println("--------------------LEADER ID--------------------");
        for(int i=0; i<N_nodes; i++){
            if(myIp != addresses[i]){
                try {
                    Socket socket = new Socket(addresses[i], ClientPort);
                    AskLeaderObject req = new AskLeaderObject(0, myIp);
                    System.out.println("Asking node "+i+" at "+addresses[i]+":"+ClientPort);
                    Sender.send(socket, req, true);
                    //Socket socket = listener.accept();
                    Object obj = Receiver.receive(socket);
                    if(obj instanceof AskLeaderObject){
                        req = (AskLeaderObject) obj;
                        if(req.getLeaderId() == -1){
                            System.out.println("Node is a Candidate... restarting the loop requests");
                            i=-1;
                            Thread.sleep(1000);
                        }
                        else{
                            System.out.println("\tNode " + i + " is alive -> Leader is " + req.getLeaderId());
                            ask.setLeaderId(req.getLeaderId());
                            System.out.println("-------------------------------------------------");
                            
                            socket.close();
                            //System.out.println("leader id done");
                            return;
                        }
                    }
                    socket.close();
                } catch (SocketTimeoutException ex){
                    System.out.println("Node " + i + " is down... try with next");
                } catch (IOException ex) {
                    System.out.println("No answer from node "+i);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(AskLeader.class.getName()).log(Level.SEVERE, null, ex);
                } catch (InterruptedException ex) {
                    Logger.getLogger(AskLeader.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        System.out.println("***FATAL -- No answer from the entire cluster -- FATAL***");
    }
}
