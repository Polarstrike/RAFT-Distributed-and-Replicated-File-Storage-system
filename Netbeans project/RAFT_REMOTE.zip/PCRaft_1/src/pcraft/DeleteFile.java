/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Giacomo
 */
public class DeleteFile extends Thread {

    String[] addresses;
    private final String myIp;
    private final int ClientPort = 9093;
    private final int leaderId, N_Nodes;    
    private final String fileName;

    public DeleteFile(String myIp, int leaderId, String fileName, int n, String[] addresses) {
        this.myIp = myIp;
        this.leaderId = leaderId;
        this.fileName = fileName;
        this.N_Nodes = n;
        this.addresses = new String[N_Nodes];
        this.addresses = addresses;
    }

    @Override
    public void run() {
        try {
            System.out.println("!!!This operation will put the cluster into an inconsistent state");
            System.out.println("!!!TEST PURPOSE ONLY");
            System.out.println("---------------------DELETE----------------------");
            AskLeaderObject request = new AskLeaderObject(4, myIp, fileName);     //readRequest
            System.out.println("Asking to delete file to node "+leaderId+" at "+addresses[leaderId]+":"+ClientPort+" for file "+fileName);
            Socket socket = new Socket(addresses[leaderId], ClientPort);
            //Sender.send(SERVER, ClientPort, request);           //send readRequest            
            Sender.send(socket, request);
            
            //Socket rSocket = listener.accept();
            
            Object obj = Receiver.receive(socket);
            if(obj instanceof AskLeaderObject){         //received reply from node
                request = (AskLeaderObject) obj;
                if(request.isAllowed()){                //i have contacted the leader
                    if(request.getFileName() != null){
                        System.out.println("File "+fileName+" DELETED");                                                
                    }
                    else{
                        System.out.println("File DOES NOT exists on server, operation DENIED");                        
                    }
                }
                else{           //operation DENIED
                    System.out.println("I haven't contacted the leader which is ("+request.getLeaderId()+"), operation DENIED");                  
                }
            }
            System.out.println("-------------------------------------------------");
        } catch (IOException ex) {
            Logger.getLogger(DeleteFile.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DeleteFile.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
    
}
