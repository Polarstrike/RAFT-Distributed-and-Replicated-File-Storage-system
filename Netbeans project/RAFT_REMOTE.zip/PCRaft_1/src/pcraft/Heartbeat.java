/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.Serializable;

/**
 *
 * @author Giacomo
 */
public class Heartbeat implements Serializable{
    
    private int term, leaderId;
    
    public Heartbeat(int term, int leaderId){
        this.term = term;
        this.leaderId = leaderId;
    }

    public int getTerm() {
        return term;
    }

    public void setTerm(int term) {
        this.term = term;
    }

    public int getLeaderId() {
        return leaderId;
    }

    public void setLeaderId(int leaderId) {
        this.leaderId = leaderId;
    }
    
    
}
