/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Scanner;

/**
 *
 * @author Giacomo
 */
public class Client {
    
    
    public static void main(String[] args) throws FileNotFoundException, InterruptedException, Exception {
            
        String nodeIp = getIp();
        System.out.println("Client on. IP: "+nodeIp);
        String clientDir = args[0];
        int N_nodes = Integer.parseInt(args[1]);
        
        String[] addresses = new String[N_nodes];
        
        File directory = new File(clientDir+"shared/");
        directory.mkdir();

        
        Scanner s = new Scanner(new File(clientDir+"ClusterAddresses.txt"));    
        System.out.println("\nCluster addresses: ");    
        for(int i=0; i<N_nodes; i++){
            addresses[i] = s.nextLine();      
            System.out.println("Node #"+i+"\t\t"+addresses[i]);
        }
        s.close(); 
        clientDir = clientDir+"shared/";
        
        Scanner in =new Scanner(System.in);
        
        String command = new String();
        System.out.println("\n");
        while(true){
            int leader = -1;
            System.out.print("\n> ");
            command = in.next();
            
            if(command.equals("leader")){
                AskLeaderObject ask = new AskLeaderObject(0, nodeIp);
                ask.setLeaderId(-1);
                AskLeader a = new AskLeader(N_nodes, nodeIp, ask, addresses);
                a.start();
                a.join();
            }
            else if(command.equals("read")){
                System.out.print("\tFile name: ");
                command = in.next();
                AskLeaderObject ask = new AskLeaderObject(0, nodeIp);
                ask.setLeaderId(-1);
                AskLeader a = new AskLeader(N_nodes, nodeIp, ask, addresses);
                a.start();
                a.join();
                leader = ask.getLeaderId();
                if(leader != -1){
                    ClientReadFile r = new ClientReadFile(nodeIp, leader, clientDir, command, N_nodes, addresses);
                    r.start();
                    r.join();
                }
                else{
                    System.out.println("Issue when contacting the leader, please retry.");
                }
            }
            else if(command.equals("write")){                
                System.out.print("\tFile name: ");
                command = in.next();
                AskLeaderObject ask = new AskLeaderObject(0, nodeIp);
                ask.setLeaderId(-1);
                AskLeader a = new AskLeader(N_nodes, nodeIp, ask, addresses);
                a.start();
                a.join();
                leader = ask.getLeaderId();
                if(leader != -1){
                    ClientWriteFile w = new ClientWriteFile(nodeIp, leader, clientDir, command, N_nodes, addresses);
                    w.start();
                    w.join();            
                }
                else{
                    System.out.println("Issue when contacting the leader, please retry.");                
                }
            }
            else if(command.equals("ls")){
                AskLeaderObject ask = new AskLeaderObject(0, nodeIp);
                ask.setLeaderId(-1);
                AskLeader a = new AskLeader(N_nodes, nodeIp, ask, addresses);
                a.start();
                a.join();
                leader = ask.getLeaderId();
                if(leader != -1){
                    AskList ls = new AskList(nodeIp, leader, addresses);
                    ls.start();
                    ls.join();           
                }
                else{
                    System.out.println("Issue when contacting the leader, please retry.");                
                }
            }
            else if (command.equals("-delete")) {
                System.out.println("***WARNING: cluster will be in an inconsistent state after this operation");
                System.out.print("\tWhich node?: ");
                command = in.next();
                int l = Integer.parseInt(command);
                
                System.out.print("\tFile name: ");
                command = in.next();
                leader = l;
                
                if(leader < 0){
                    DeleteFile del = new DeleteFile(nodeIp, leader, command, N_nodes, addresses);
                    del.start();
                    del.join();           
                }
                else{
                    System.out.println("Wrong leader id.");                
                }
            }
            else if (command.equals("quit") || command.equals("exit")) {                              
                return;
            }
            else if (command.equals("-ls")){
                System.out.print("Target node: ");
                command = in.next();
                leader = Integer.parseInt(command);
                if(leader >= 0 || leader < N_nodes){
                    AskList ls = new AskList(nodeIp, leader, addresses);
                    ls.start();
                    ls.join();         
                }
                else{
                    System.out.println("Issue when contacting the leader, please retry.");                
                }
            }
        }
    }

    public static String getIp() throws Exception {
        URL whatismyip = new URL("http://checkip.amazonaws.com");
        BufferedReader in = null;
        try {
            in = new BufferedReader(new InputStreamReader(
                    whatismyip.openStream()));
            String ip = in.readLine();
            return ip;
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }    
}
