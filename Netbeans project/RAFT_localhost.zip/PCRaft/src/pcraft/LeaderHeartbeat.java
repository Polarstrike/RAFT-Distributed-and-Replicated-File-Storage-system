/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.IOException;
import java.net.ConnectException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Giacomo
 */
public class LeaderHeartbeat extends Thread{
    
    private final int targetNode;
    private static final int HBport = 9090;
    private ServerSocket listener;
    private Semaphore sem;
    NodeState state;
    
    public LeaderHeartbeat(NodeState s, int targetNode, ServerSocket listener, Semaphore sem){
        this.targetNode = targetNode;
        this.state = s;
        this.listener = listener;
        this.sem = sem;
    }
    
    @Override
    public void run(){        
        System.out.println("LeaderHeartbeat spawned, target is node "+targetNode+"\t at "+state.addresses[targetNode]+":"+HBport);
        int i = 0;
        while(!Thread.currentThread().isInterrupted()){
            try {
                //ADDED
                /*
                if(Thread.currentThread().isInterrupted()){
                    System.out.println("turn off!!!!!!!!!!");
                    return;
                }
                */
                //
                try {
                    i++;
                    Heartbeat hb = new Heartbeat(state.getCurrentTerm(), state.getNodeId());
                    Sender.send(state.addresses[targetNode], HBport, hb, true);     //send with timeout
                    Socket socket = listener.accept();
                    Object obj = Receiver.receive(socket);
                    if(obj instanceof HeartbeatReply){
                        HeartbeatReply reply = (HeartbeatReply) obj;
                        //added
                        if(reply.isSuccess()) {
                            if (i % 32 == 0) 
                                System.out.println("Node " + reply.getSenderId() + " UP\tNode term: " + reply.getTerm());
                            
                        }
                        else{
                            //END THIS THREAD convert to follower, a newer leader exists :(
                            //System.out.println("Newer leader exist, stopping and will convert to follower "+targetNode);
                            //System.out.println("Turning off "+targetNode);
                            sem.release();
                            return;
                        }
                        
                        //
                        
                        /* ORIGINAL
                        if(i%32 == 0)
                            System.out.println("Node " + reply.getSenderId() + " UP\tNode term: "+reply.getTerm());
                        */
                    }
                    socket.close();
                } catch (SocketTimeoutException ex){
                    if(i%32==0)
                        System.out.println("Node "+ targetNode +" connection timeout (DOWN)");
                } catch (ConnectException ex){
                    System.out.println("Node "+ targetNode +" connection refused (DOWN)");
                    Logger.getLogger(LeaderHeartbeat.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(LeaderHeartbeat.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(LeaderHeartbeat.class.getName()).log(Level.SEVERE, null, ex);
                }
                Thread.sleep(50);
            } catch (InterruptedException ex){
                //System.out.println("turn off!!!!!!!!!! "+targetNode);
                return;
                //Logger.getLogger(LeaderHeartbeat.class.getName()).log(Level.SEVERE, null, ex);
            }            
        }
        //System.out.println("Interrupted, turning off "+targetNode);
        return;
    }
}
