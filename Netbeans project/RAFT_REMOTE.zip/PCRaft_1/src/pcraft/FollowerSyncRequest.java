/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Giacomo
 */
public class FollowerSyncRequest extends Thread{
    private final static int LeaderSyncPort = 9095;
    private final NodeState state;
    
    public FollowerSyncRequest(NodeState s){
        this.state = s;
    }
    
    @Override
    public void run(){
        try {
//Ask the cluster to find the leader id 
            String nodeIp = state.addresses[state.getNodeId()];
            AskLeaderObject ask = new AskLeaderObject(0, nodeIp);
            ask.setLeaderId(-1);
            AskLeaderInCluster a = new AskLeaderInCluster(state.N_nodes, state.getNodeId(), ask, state);
            a.start();
            a.join();
            System.out.println("Leader is node " + ask.getLeaderId());
            int leader = ask.getLeaderId();
//Obtain the file list of the leader node            
            if (leader != -1) {
                ask = new AskLeaderObject(0, nodeIp);
                AskList ls = new AskList(nodeIp, leader, ask, state.addresses);
                ls.start();
                ls.join();
                

                List<FileState> myList = state.getFileStates();
                List<FileState> leaderList = ask.getFileStates();
                List<FileState> leaderOnlyList = new ArrayList<>(leaderList);
                List<FileState> localOnlyList = new ArrayList<>(myList);
                FileState tmp;

//Obtain the local and leader only files                
                leaderOnlyList.removeAll(myList);
                localOnlyList.removeAll(leaderList);

                /*
                System.out.println("leaderlist "+leaderList.size());
                for (int i = 0; i < leaderList.size(); i++) {
                    tmp = leaderList.get(i);
                    Date date = new Date(tmp.getTimestamp());
                    System.out.println("\t" + tmp.getFileName() + "\t"+tmp.getTimestamp()+"\t" + date);
                }
                System.out.println("------------\nmyList");
                for (int i = 0; i < myList.size(); i++) {
                    tmp = myList.get(i);
                    Date date = new Date(tmp.getTimestamp());
                    System.out.println("\t" + tmp.getFileName() + "\t"+tmp.getTimestamp()+ "\t" + date);
                }
                */
                
                
                System.out.println("\n------------ DIFFERENCES ------------");
                System.out.println("leaderOnly");
                if(leaderOnlyList.size() == 0){
                    System.out.println("\tnone");
                }
                else{
                    for (int i = 0; i < leaderOnlyList.size(); i++) {
                        tmp = leaderOnlyList.get(i);
                        Date date = new Date(tmp.getTimestamp());
                        System.out.println("\t" + tmp.getFileName() + "\t"+tmp.getTimestamp()+ "\t" + date);
                    }
                }

                System.out.println("localOnly");
                if(localOnlyList.size() == 0){
                    System.out.println("\tnone");
                }
                else{
                    for (int i = 0; i < localOnlyList.size(); i++) {
                        tmp = localOnlyList.get(i);
                        Date date = new Date(tmp.getTimestamp());
                        System.out.println("\t" + tmp.getFileName() + "\t"+tmp.getTimestamp()+ "\t" + date);
                    }
                }

//1)delete all localOnly files
                System.out.println("----------LOCAL DELETION-------------");
                for (int i = 0; i < localOnlyList.size(); i++) {
                    tmp = localOnlyList.get(i);
                    File f = new File(state.getDir()+tmp.getFileName());
                    f.delete();
                    System.out.println("Local file " + tmp.getFileName() + " deleted");
                }
                System.out.println("-------------------------------------");

//2)download all leaderOnly files from leader  DURING THIS OPERATION CLIENT write ACCESS MUST BE FORBIDDEN
                AskLeaderObject syncReq = new AskLeaderObject(5, nodeIp);
                syncReq.setFileStates(leaderOnlyList);
                System.out.println("trying connect on "+state.addresses[leader]+"\t"+LeaderSyncPort);
                Socket socket = new Socket(state.addresses[leader], LeaderSyncPort);
                System.out.println("leader connected");
                Sender.send(socket, syncReq);

//3) for loop to receive all missing files from leader
                System.out.println("----------FILE SYNC------------------");            
                for(int i=0; i<leaderOnlyList.size(); i++){
                    tmp = leaderOnlyList.get(i);
                    System.out.println("Now receiving from leader file " + tmp.getFileName());
                    //receive file
                    Receiver.receiveFileFrom(socket, state.getDir(), tmp.getFileName(), tmp.getFileSize());

                    File f = new File(state.getDir() + tmp.getFileName());
                    f.setLastModified(tmp.getTimestamp());
                    System.out.println("File "+tmp.getFileName()+"\t CORRECTLY RECEIVED (stored in permanent dir.)");
                }

//4) Update file list currently on this node
                state.updateFileStates();


                System.out.println("-------------------------------------");
                System.out.println("Follower is now in SYNC... terminating FollowerSyncRequest Thread\n");
                
            }
            else {
                System.err.println("Leader not found, cluster unavailable");
            }
        } catch (SocketException ex){
            Logger.getLogger(FollowerSyncRequest.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex){
            System.err.println("File not found");
        } catch (InterruptedException | IOException ex) {
            Logger.getLogger(FollowerSyncRequest.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
    
}
