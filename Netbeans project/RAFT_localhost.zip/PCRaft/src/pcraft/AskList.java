/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Giacomo
 */
public class AskList extends Thread{
    
    String[] addresses = new String[] {"127.0.0.1", "127.0.0.2", "127.0.0.3", "127.0.0.4", "127.0.0.5"};
    private final String myIp;
    private final int ClientPort = 9093;
    private final int leaderId;
    private AskLeaderObject ask;
    
    public AskList(String myIp, int leaderId){
        this.myIp = myIp;        
        this.leaderId = leaderId;
        this.ask = null;
    }
    
    public AskList(String myIp, int leaderId, AskLeaderObject ask){
        this.myIp = myIp;        
        this.leaderId = leaderId;
        this.ask = ask;
    }
    
    @Override
    public void run(){
        try {
            System.out.println("-----------------------LS-----------------------");
            AskLeaderObject req = new AskLeaderObject(3, myIp);
            System.out.println("Asking ls to node "+leaderId+" (leader) at "+addresses[leaderId]+":"+ClientPort);
            Socket socket = new Socket(addresses[leaderId], ClientPort);
            Sender.send(socket, req);
            //Sender.send(addresses[leaderId], ClientPort , req, true);
            //Socket socket = listener.accept();
            Object obj = Receiver.receive(socket);
            if(obj instanceof AskLeaderObject){
                req = (AskLeaderObject) obj;
                if(req.getLeaderId() == -1){
                    System.out.println("Node is a Candidate... quitting");
                    socket.close();
                    return;
                }
                else{
                    List<FileState> fileStates = req.getFileStates();
                    if(ask != null)
                        ask.setFileStates(fileStates);
                    FileState tmp;
                    System.out.println("Leader ("+leaderId+") is alive, files are:");
                    for(int i=0; i<fileStates.size(); i++){
                        tmp = fileStates.get(i);
                        Date date = new Date(tmp.getTimestamp());
                        System.out.println("\t" + tmp.getFileName() + "\t" + date + "\t" + date.getTime());
                    }
                    System.out.println("------------------------------------------------");
                    socket.close();
                    return;
                }
            }                
            
        } catch (SocketTimeoutException ex){
            System.out.println("Node " + leaderId + " is down... ");            
        } catch (IOException ex) {
            System.out.println("No answer from node "+leaderId);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AskLeader.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
