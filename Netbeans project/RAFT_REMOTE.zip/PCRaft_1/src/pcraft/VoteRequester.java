/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pcraft;

import java.io.IOException;
import java.net.ConnectException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Giacomo
 */
public class VoteRequester extends Thread {

    private final static int VoteRequestPort = 9091;
    private NodeState state;
    private int targetNode;
    private ServerSocket listener;

    public VoteRequester(NodeState s, int target, ServerSocket listener) {
        this.targetNode = target;
        this.state = s;
        this.listener = listener;               
    }

    @Override
    public void run() {
        try {
            System.out.println("VoteRequester spawned, target is node " + targetNode);
            VoteRequest request = new VoteRequest(state.getCurrentTerm(), state.getNodeId());       //ask vote
            Sender.send(state.addresses[targetNode], VoteRequestPort, request, true);     //send with timeout
            listener.setSoTimeout(300);
            Socket socket = listener.accept();
            Object obj = Receiver.receive(socket);
            if (obj instanceof VoteReply) {
                VoteReply reply = (VoteReply) obj;
                System.out.println("Node " + reply.getSenderId() + " voted: "+reply.isVoteGranted()); 
                if(reply.isVoteGranted()){      //got the vote
                    state.incrementObtainedVote();      //increment obtained vote counter
                    System.out.println("obtainedVote incremented");
                }
               
            }

        } catch (SocketTimeoutException ex) {
            System.out.println("Node " + targetNode + " connection timeout (DOWN no voteReply)");
        } catch (IOException ex) {
            Logger.getLogger(VoteRequester.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(VoteRequester.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
